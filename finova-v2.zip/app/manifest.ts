import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Risk Analiz",

    short_name: "Risk Analiz",

    description:
      "Finansal Risk Analiz Platformu",

    start_url: "/",

    display: "standalone",

    background_color: "#030712",

    theme_color: "#06b6d4",

    icons: [
      {
        src: "/icon-192.png",
        sizes: "192x192",
        type: "image/png",
      },

      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
      },
    ],
  };
}